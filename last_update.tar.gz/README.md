A Flappy Bird Clone for PC
=============

CONTROLS: 

Click or Press SPACE BAR to let bird flap 

DEPENDENCIES:

Pygame 1.9.1 (Python 2)

Pygame 1.9.2 (Python 3)

To install dependencies for Python 2.x:

	pip install pygame

VIDEO DEMO:

DISCLAIMER:

This project is intended for non-commercial educational purposes. 
